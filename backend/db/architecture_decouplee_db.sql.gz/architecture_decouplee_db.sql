-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `uuid` varchar(36) NOT NULL COMMENT 'UUID v4',
  `title` varchar(64) NOT NULL,
  `slug` varchar(64) NOT NULL COMMENT 'title slug version, unique',
  `body` text NOT NULL,
  `summary` mediumtext NOT NULL COMMENT 'body summary',
  `user_uuid` varchar(36) NOT NULL COMMENT 'author of the post',
  UNIQUE KEY `slug_unique` (`slug`),
  UNIQUE KEY `uuid_unique` (`uuid`),
  KEY `slug` (`slug`),
  KEY `uuid` (`uuid`),
  KEY `user_uuid_uuid` (`user_uuid`,`uuid`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_uuid`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `posts_tags`;
CREATE TABLE `posts_tags` (
  `post_uuid` varchar(64) NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  KEY `tag_id` (`tag_id`),
  KEY `post_uuid` (`post_uuid`),
  CONSTRAINT `posts_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`),
  CONSTRAINT `posts_tags_ibfk_3` FOREIGN KEY (`post_uuid`) REFERENCES `posts` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(24) NOT NULL COMMENT 'unique',
  `slug` varchar(24) NOT NULL COMMENT 'name slug version, unique',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  UNIQUE KEY `slug_unique` (`slug`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uuid` varchar(36) NOT NULL COMMENT 'UUID v4',
  `firstname` varchar(24) NOT NULL,
  `lastname` varchar(24) NOT NULL,
  `email` varchar(24) NOT NULL COMMENT 'unique',
  `password` char(60) NOT NULL COMMENT 'bcrypt',
  UNIQUE KEY `uuid_unique` (`uuid`),
  UNIQUE KEY `email_unique` (`email`),
  KEY `email` (`email`),
  KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 2021-07-22 17:17:58
